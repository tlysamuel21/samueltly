import numpy as np
from argparse import ArgumentParser
from math import pi, sin, cos
from scipy.sparse import lil_matrix, csc_matrix, bmat
from scipy.sparse.linalg import splu

from fe_utils import UnitSquareMesh, FunctionSpace, Function, LagrangeElement
from fe_utils.finite_elements import VectorFiniteElement
from fe_utils.quadrature import gauss_quadrature
from fe_utils.utils import errornorm


def analytical_solution(x):
    """Return the analytical solution for velocity (u_x, u_y)."""
    u_x = 2 * pi * sin(2 * pi * x[1]) * (1 - cos(2 * pi * x[0]))
    u_y = -2 * pi * sin(2 * pi * x[0]) * (1 - cos(2 * pi * x[1]))
    return np.array([u_x, u_y])


def analytical_pressure(x):
    """Return the constant analytical pressure (0)."""
    return 0.0


def forcing_term(x):
    """Compute the forcing term for the right-hand side."""
    f_x =  -4. * pi**3 * sin(2 * pi * x[1]) * (2 * cos(2 * pi * x[0]) - 1)
    f_y =  -4.* pi**3 * sin(2 * pi * x[0]) * (1 - 2 * cos(2 * pi * x[1]))
    return np.array([f_x, f_y])


def boundary_nodes(V):
    """Return the boundary nodes where Dirichlet conditions apply."""
    eps = 1e-10
    marker = Function(V)
    marker.interpolate(lambda x: (1., 1.) if (
        x[0] < eps or x[0] > 1 - eps or x[1] < eps or x[1] > 1 - eps
        ) else (0., 0.))
    return [i for i, val in enumerate(marker.values) if np.any(val != 0.0)]


def impose_boundary_conditions(A, B, Z, F, V, P):
    """Apply boundary conditions to the system."""
    n = V.node_count
    bnodes = boundary_nodes(V)
    
    # Apply Dirichlet boundary conditions to the velocity field
    A[bnodes, :] = 0
    A[bnodes, bnodes] = 1
    F[bnodes] = 0

    # Fix the pressure to zero at a point
    B[0, :] = 0
    Z[0, 0] = 1  
    F[n] = 0

    return A, B, Z, F


def assemble(V, P, f):
    """Assemble the finite element system."""
    n, m = V.node_count, P.node_count
    A = lil_matrix((n, n))
    B = lil_matrix((m, n))
    Z = lil_matrix((m, m))
    F = np.zeros(n + m)

    mesh = V.mesh
    quad = gauss_quadrature(V.element.cell, 2 * V.element.degree)

    psi = V.element.tabulate(quad.points, grad=True)
    psi_vals = V.element.tabulate(quad.points, grad=False)
    phi_p = P.element.tabulate(quad.points, grad=False)

    # Loop over each cell to assemble the system
    for c in range(mesh.entity_counts[-1]):
        J = mesh.jacobian(c)
        detJ = abs(np.linalg.det(J))
        J_inv = np.linalg.inv(J)

        u_nodes = V.cell_nodes[c]
        p_nodes = P.cell_nodes[c]

        # Gradient of vector basis functions in physical coordinates
        grad_psi = np.einsum("ca,pjcb->pjab", J_inv, psi)

        # Strain tensor
        strain = 0.5 * (grad_psi + np.einsum("pjab->pjba", grad_psi))
        local_A = np.einsum("piab,pjab,p->ij", strain, strain, quad.weights) * detJ
        A[np.ix_(u_nodes, u_nodes)] += local_A

        # Divergence (trace of gradient)
        div_psi = np.trace(grad_psi, axis1=2, axis2=3)
        local_B = np.einsum("pj,pi,p->ji", phi_p, div_psi, quad.weights) * detJ
        B[np.ix_(p_nodes, u_nodes)] += local_B

        # Right-hand side
        local_F = np.einsum(
            "k,qkj,qij,q->i", f.values[u_nodes], psi_vals, psi_vals, quad.weights
        ) * detJ
        F[u_nodes] += local_F

    return A, B, Z, F


def solve_mastery(resolution, analytic=False, return_error=False):
    """Solve the finite element system and compute the error."""
    mesh = UnitSquareMesh(resolution, resolution)

    V = FunctionSpace(mesh, VectorFiniteElement(LagrangeElement(mesh.cell, 2)))
    P = FunctionSpace(mesh, LagrangeElement(mesh.cell, 1))

    n, m = V.node_count, P.node_count

    f = Function(V)
    f.interpolate(forcing_term)

    A, B, Z, F = assemble(V, P, f)
    A, B, Z, F = impose_boundary_conditions(A, B, Z, F, V, P)

    M_csc = bmat([[A, B.T], [B, Z]], format="lil")
    solver = splu(csc_matrix(M_csc))
    solution = solver.solve(F)

    u = Function(V)
    p = Function(P)
    u.values[:] = solution[:n]
    p.values[:] = solution[n:]

    u_analytic = Function(V)
    p_analytic = Function(P)
    u_analytic.interpolate(analytical_solution)
    p_analytic.interpolate(analytical_pressure)

    err_u = errornorm(u_analytic, u)
    err_p = errornorm(p_analytic, p)
    error = np.sqrt(err_u**2 + err_p**2)

    return (u, p), error


if __name__ == "__main__":
    parser = ArgumentParser(description="Mastery problem solver")
    parser.add_argument("--analytic", action="store_true")
    parser.add_argument("--error", action="store_true")
    parser.add_argument("resolution", type=int, nargs=1)
    args = parser.parse_args()

    resolution = args.resolution[0]
    analytic_mode = args.analytic
    show_error = args.error

    result = solve_mastery(resolution, analytic=analytic_mode)
    if analytic_mode:
        u, p = result
    elif show_error:
        (u, p), error = result
        print(f"L² Error: {error:.6e}")
    else:
        u, p = result

    u.plot()
    p.plot()
